
#include "SailSimPhysicsModule.h"
#define LOCTEXT_NAMESPACE "FSailSimPhysicsModule"

void FSailSimPhysicsModule::StartupModule()
{
    // Module startup logic
}

void FSailSimPhysicsModule::ShutdownModule()
{
    // Module shutdown logic
}

#undef LOCTEXT_NAMESPACE
IMPLEMENT_MODULE(FSailSimPhysicsModule, SailSimPhysics);
