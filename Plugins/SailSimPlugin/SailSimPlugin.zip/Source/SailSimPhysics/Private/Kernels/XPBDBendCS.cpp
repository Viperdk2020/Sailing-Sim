
#include "Kernels/XPBDBendCS.h"
IMPLEMENT_GLOBAL_SHADER(FXPBDBendCS, "/Shaders/XPBDBend.usf", "MainCS", SF_Compute);
