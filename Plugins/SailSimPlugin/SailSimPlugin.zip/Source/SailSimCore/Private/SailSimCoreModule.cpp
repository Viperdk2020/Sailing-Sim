
#include "SailSimCoreModule.h"
#define LOCTEXT_NAMESPACE "FSailSimCoreModule"

void FSailSimCoreModule::StartupModule()
{
    // Module startup logic
}

void FSailSimCoreModule::ShutdownModule()
{
    // Module shutdown logic
}

#undef LOCTEXT_NAMESPACE
IMPLEMENT_MODULE(FSailSimCoreModule, SailSimCore);
