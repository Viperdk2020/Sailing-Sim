
#include "SailSimRenderingModule.h"
#define LOCTEXT_NAMESPACE "FSailSimRenderingModule"

void FSailSimRenderingModule::StartupModule()
{
    // Module startup logic
}

void FSailSimRenderingModule::ShutdownModule()
{
    // Module shutdown logic
}

#undef LOCTEXT_NAMESPACE
IMPLEMENT_MODULE(FSailSimRenderingModule, SailSimRendering);
