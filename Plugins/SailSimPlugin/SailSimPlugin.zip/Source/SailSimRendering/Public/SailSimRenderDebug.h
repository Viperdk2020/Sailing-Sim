// TODO: Debug drawing helpers
