using UnrealBuildTool;

public class SailCloth : ModuleRules
{
    public SailCloth(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

        PublicDependencyModuleNames.AddRange(new string[]
        {
            "Core",
            "CoreUObject",
            "Engine",
            "RenderCore",
            "RHI",
            "SailClothPhysics"
        });

        PrivateDependencyModuleNames.AddRange(new string[] { });
    }
}
