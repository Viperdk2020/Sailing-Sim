#include "Components/SailClothComponent.h"
#include "SailClothPhysics/Public/SailPhysicsManager.h"
#include "SailClothPhysics/Public/SailPhysicsUtils.h"


USailClothComponent::USailClothComponent()
{
    PrimaryComponentTick.bCanEverTick = true;
}

void USailClothComponent::InitializeComponent()
{
    Super::InitializeComponent();

    // Create and initialize physics manager with vertex count
    PhysicsManager = MakeShared<FSailPhysicsManager>();
    PhysicsManager->Initialize(SailSettings.NumVertices);
}

void USailClothComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
    Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

    if (PhysicsManager.IsValid())
    {
        // Update simulation each frame on render thread
        ENQUEUE_RENDER_COMMAND(SimulateCloth)(
            [PhysicsManager = PhysicsManager, DeltaTime](FRHICommandListImmediate& RHICmdList)
            {
                PhysicsManager->Simulate(RHICmdList, DeltaTime);
            }
        );
    }
}
