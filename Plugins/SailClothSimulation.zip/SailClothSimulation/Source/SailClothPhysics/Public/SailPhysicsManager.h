#pragma once

#include "CoreMinimal.h"
#include "RHI.h"
#include "RenderGraphUtils.h"
#include "RHIResources.h" // For FRWBufferStructured
#include "RHIResources.h"

class FSailPhysicsManager
{
public:
    FSailPhysicsManager();
    ~FSailPhysicsManager();

    void Initialize(uint32 InVertexCount);
    void Release();

    void Simulate(FRHICommandListImmediate& RHICmdList, float DeltaTime);

    FRWBufferStructured& GetPositionsBuffer() { return PositionsBuffer; }
    FRWBufferStructured& GetVelocitiesBuffer() { return VelocitiesBuffer; }
    FRWBufferStructured& GetNormalsBuffer() { return NormalsBuffer; }

private:
    uint32 VertexCount = 0;

    FRWBufferStructured PositionsBuffer;
    FRWBufferStructured VelocitiesBuffer;
    FRWBufferStructured NormalsBuffer;

    void DispatchXPBDStretchCS(FRHICommandListImmediate& RHICmdList, float DeltaTime);
    void DispatchXPBDBendCS(FRHICommandListImmediate& RHICmdList, float DeltaTime);
    void DispatchVLMJacobiCS(FRHICommandListImmediate& RHICmdList, float DeltaTime);

    void InitializeBuffers();
};
