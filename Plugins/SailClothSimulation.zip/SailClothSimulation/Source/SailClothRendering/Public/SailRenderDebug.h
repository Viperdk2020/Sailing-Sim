#pragma once
#include "RenderGraphBuilder.h"
class FSailRenderDebug {
public:
    static void AddDebugPass(FRDGBuilder& GraphBuilder);
};