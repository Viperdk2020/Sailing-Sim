#pragma once

#include "CoreMinimal.h"
#include "RenderResource.h"
#include "VertexFactory.h"
#include "RHIResources.h"

class FRHICommandListImmediate;
class FSailPhysicsManager;

/** Custom Vertex Factory to fetch vertex positions from GPU buffers */
class FSailRenderDeformer : public FVertexFactory
{
    DECLARE_VERTEX_FACTORY_TYPE(FSailRenderDeformer);

public:
    FSailRenderDeformer(ERHIFeatureLevel::Type InFeatureLevel);

    virtual void InitRHI() override;

    /** Bind the positions buffer from the physics simulation */
    void BindPositionBuffer(FRHICommandListImmediate& RHICmdList, FRWBufferStructured& PositionsBuffer);

private:
    /** GPU vertex position buffer */
    FVertexBufferRHIRef PositionBufferRHI;

    /** Shader resource view of the position buffer */
    FShaderResourceViewRHIRef PositionBufferSRV;
};
