#include "SailRenderDeformer.h"
#include "ShaderParameterUtils.h"
#include "RHICommandList.h"
#include "RenderGraphUtils.h"
#include "SailClothPhysics/SailPhysicsManager.h"

IMPLEMENT_VERTEX_FACTORY_TYPE(FSailRenderDeformer, "/Plugin/SailClothSimulation/Shaders/SailRenderDeformerVS.usf", "MainVS", true);

FSailRenderDeformer::FSailRenderDeformer(ERHIFeatureLevel::Type InFeatureLevel)
    : FVertexFactory(InFeatureLevel)
{
}

void FSailRenderDeformer::InitRHI()
{
    // Setup vertex stream components, typically bind position/index buffers here
    FVertexStreamComponent PositionStream;
    if (PositionBufferRHI.IsValid())
    {
        PositionStream = FVertexStreamComponent(PositionBufferRHI, 0, sizeof(FVector4f), VET_Float4);
    }
    else
    {
        // Use dummy stream if no buffer bound
        PositionStream = FVertexStreamComponent(GNullVertexBuffer.VertexBufferRHI, 0, sizeof(FVector4f), VET_Float4);
    }

    InitDeclaration({
        PositionStream
    });
}

void FSailRenderDeformer::BindPositionBuffer(FRHICommandListImmediate& RHICmdList, FRWBufferStructured& PositionsBuffer)
{
    PositionBufferRHI = PositionsBuffer.Buffer;
    PositionBufferSRV = PositionsBuffer.SRV;

    // Mark vertex factory to update resource as buffer changed
    UpdateRHI();
}

void FSailRenderDeformer::InitResource()
{
    // Initialization logic here
    FVertexFactory::InitResource();
}
