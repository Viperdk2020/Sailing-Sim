#include "SailRenderDebug.h"
void FSailRenderDebug::AddDebugPass(FRDGBuilder& GraphBuilder) {
    // Stub implementation
}