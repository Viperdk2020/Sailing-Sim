
#include "Kernels/XPBDStretchCS.h"
IMPLEMENT_GLOBAL_SHADER(FXPBDStretchCS, "/SailSimPlugin/XPBDStretch.usf", "MainCS", SF_Compute);
