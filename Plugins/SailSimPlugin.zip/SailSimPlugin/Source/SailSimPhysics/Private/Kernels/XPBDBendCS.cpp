
#include "Kernels/XPBDBendCS.h"
IMPLEMENT_GLOBAL_SHADER(FXPBDBendCS, "/SailSimPlugin/XPBDBend.usf", "MainCS", SF_Compute);
