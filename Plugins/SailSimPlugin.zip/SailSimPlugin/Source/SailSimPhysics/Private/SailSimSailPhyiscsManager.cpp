#pragma once

#include "SailSimSailPhyiscsManager.h"


SailSimSailPhyiscsManager::SailSimSailPhyiscsManager()
{
}

SailSimSailPhyiscsManager::~SailSimSailPhyiscsManager()
{
}
