
#include "SailRenderDebug.h"
#include "RenderGraphUtils.h"
#include "Debug/DebugDrawService.h"
#include "Engine/Engine.h"

static TAutoConsoleVariable<int32> CVarSailDbg(
    TEXT("s.Sail.Debug"), 0, TEXT("Toggle SailSim debug draws"), ECVF_Cheat);

bool FSailRenderDebug::IsEnabled(){ return CVarSailDbg.GetValueOnAnyThread()!=0; }

void FSailRenderDebug::AddConstraintDebug(
    FRDGBuilder& Graph,
    FRDGBufferSRVRef PosSRV,
    FRDGBufferSRVRef StretchSRV,
    uint32 NumPairs,
    const FMatrix& L2W)
{
#if !(UE_BUILD_SHIPPING || UE_BUILD_TEST)
    if(!IsEnabled()) return;

    AddDebugLinePass(Graph, RDG_EVENT_NAME("SailStretchDebug"),
    [PosSRV, StretchSRV, NumPairs, L2W](FRHICommandListImmediate& RHICmd)
    {
        const FVector4f* Pos = (const FVector4f*)Graph.BufferSRVRead(PosSRV);
        const uint2* Pairs   = (const uint2*)   Graph.BufferSRVRead(StretchSRV);

        for(uint32 i=0;i<NumPairs;++i)
        {
            FVector A=L2W.TransformPosition((FVector)Pos[Pairs[i].x]);
            FVector B=L2W.TransformPosition((FVector)Pos[Pairs[i].y]);
            float Err=FMath::Clamp((A-B).Size()*10.f,0.f,1.f);
            FLinearColor C=FLinearColor::LerpUsingHSV(FLinearColor::Green,FLinearColor::Red,Err);
            DrawDebugLine(RHICmd,A,B,C.ToFColor(true),false,0.f,0,1.f);
        }
    });
#endif
}

void FSailRenderDebug::AddLiftVectorDebug(
    FRDGBuilder& Graph,
    FRDGBufferSRVRef Strip0SRV,
    uint32 NumStrips,
    const FMatrix& L2W)
{
#if !(UE_BUILD_SHIPPING || UE_BUILD_TEST)
    if(!IsEnabled()) return;

    AddDebugLinePass(Graph, RDG_EVENT_NAME("SailLiftDebug"),
    [Strip0SRV, NumStrips, L2W](FRHICommandListImmediate& RHICmd)
    {
        const FVector4f* Info=(const FVector4f*)Graph.BufferSRVRead(Strip0SRV);
        for(uint32 s=0;s<NumStrips;++s)
        {
            FVector C=L2W.TransformPosition((FVector)Info[s].xyz);
            FVector Tip=C+L2W.TransformVector(FVector(0,0,1))*20.f;
            DrawDebugDirectionalArrow(RHICmd,C,Tip,5.f,FColor::Cyan,false,0.f,0,1.f);
        }
    });
#endif
}
