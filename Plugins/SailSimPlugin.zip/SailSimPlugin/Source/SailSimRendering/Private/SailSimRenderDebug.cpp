
#include "SailSimRenderDebug.h"
#include "RenderGraphUtils.h"
#include "RHICommandList.h"
#include "RHIGPUReadback.h"
#include "Engine/Engine.h"

static TAutoConsoleVariable<int32> CVarSailDbg(
    TEXT("s.Sail.Debug"), 0, TEXT("Toggle SailSim debug draws"), ECVF_Cheat);

bool FSailRenderDebug::IsEnabled() { return CVarSailDbg.GetValueOnAnyThread() != 0; }

/*---------------- Constraint debug ----------------*/
void FSailRenderDebug::AddConstraintDebug(
    FRDGBuilder& Graph,
    FRDGBufferRef PosBuffer,
    FRDGBufferSRVRef PosSRV,
    FRDGBufferRef StretchBuffer,
    FRDGBufferSRVRef StretchSRV,
    uint32 NumPairs,
    const FMatrix& L2W)
{
#if !(UE_BUILD_SHIPPING || UE_BUILD_TEST)
    if (!IsEnabled()) return;

    auto* PosRead = new FRHIGPUBufferReadback(TEXT("Sail.PosRead"));
    auto* PairRead = new FRHIGPUBufferReadback(TEXT("Sail.PairRead"));

    Graph.AddPass(
        RDG_EVENT_NAME("SailStretchReadback"),
        ERDGPassFlags::Copy,
        [PosBuffer, StretchBuffer, PosRead, PairRead, &Graph](FRHICommandListImmediate& RHICmd)
        {
            PosRead->EnqueueCopy(RHICmd, Graph.RHIAccess(PosBuffer));
            PairRead->EnqueueCopy(RHICmd, Graph.RHIAccess(StretchBuffer));
        });

    ENQUEUE_RENDER_COMMAND(SailStretchDebugCmd)(
        [PosRead, PairRead, NumPairs, L2W](FRHICommandListImmediate& RHICmd)
        {
            if (!PosRead->IsReady() || !PairRead->IsReady()) return;

            const FVector4f* Pos = reinterpret_cast<const FVector4f*>(PosRead->Lock(0));
            const uint32* Pair = reinterpret_cast<const uint32*>(PairRead->Lock(0));

            for (uint32 i = 0; i < NumPairs; ++i)
            {
                uint32 v0 = Pair[i * 2 + 0];
                uint32 v1 = Pair[i * 2 + 1];

                FVector A = L2W.TransformPosition(FVector(Pos[v0].X, Pos[v0].Y, Pos[v0].Z));
                FVector B = L2W.TransformPosition(FVector(Pos[v1].X, Pos[v1].Y, Pos[v1].Z));

                float err = FMath::Clamp((A - B).Size() * 10.f, 0.f, 1.f);
                FColor col = FLinearColor::LerpUsingHSV(FLinearColor::Green, FLinearColor::Red, err).ToFColor(true);

                DrawDebugLine(RHICmd, A, B, col, false, 0.f, 0, 1.f);
            }

            PosRead->Unlock();
            PairRead->Unlock();
            delete PosRead;
            delete PairRead;
        });
#endif
}


/*---------------- Lift vector debug --------------*/
void FSailRenderDebug::AddLiftVectorDebug(
    FRDGBuilder& Graph,
    FRDGBufferSRVRef Strip0SRV,
    uint32 NumStrips,
    const FMatrix& L2W)
{
#if !(UE_BUILD_SHIPPING || UE_BUILD_TEST)
    if (!IsEnabled()) return;

    auto* StripRead = new FRHIGPUBufferReadback(TEXT("Sail.StripRead"));

    Graph.AddPass(
        RDG_EVENT_NAME("SailLiftReadback"),
        ERDGPassFlags::Copy,
        [Strip0SRV, StripRead](FRHICommandListImmediate& RHICmd)
        {
           StripRead->EnqueueCopy(RHICmd, Strip0SRV->GetBuffer());

        });

    ENQUEUE_RENDER_COMMAND(SailLiftDebugCmd)(
        [StripRead, NumStrips, L2W](FRHICommandListImmediate& RHICmd)
        {
            if (!StripRead->IsReady()) return;

            const FVector4f* Info = reinterpret_cast<const FVector4f*>(StripRead->Lock(0));

            for (uint32 s = 0; s < NumStrips; ++s)
            {
                FVector C = L2W.TransformPosition(FVector(Info[s].X, Info[s].Y, Info[s].Z));
                FVector Tip = C + L2W.TransformVector(FVector(0, 0, 1)) * 20.f;
                DrawDebugDirectionalArrow(RHICmd, C, Tip, 5.f, FColor::Cyan, false, 0.f, 0, 1.f);
            }

            StripRead->Unlock();
            delete StripRead;
        });
#endif
}
