// TODO: Debug drawing helpers

// SailSimRenderDebug.h
#pragma once
#include "CoreMinimal.h"
#include "RenderGraphBuilder.h"

class FSailRenderDebug
{
public:
    static void AddConstraintDebug(
        FRDGBuilder& Graph,
        FRDGBufferSRVRef Positions,
        FRDGBufferSRVRef StretchPairs,
        uint32  NumPairs,
        const FMatrix& LocalToWorld);

    static void AddLiftVectorDebug(
        FRDGBuilder& Graph,
        FRDGBufferSRVRef StripInfo0,
        uint32  NumStrips,
        const FMatrix& LocalToWorld);

    /** console toggle */
    static bool IsEnabled();
};


